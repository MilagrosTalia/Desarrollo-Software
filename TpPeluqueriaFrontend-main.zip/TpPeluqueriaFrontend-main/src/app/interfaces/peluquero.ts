export interface Peluquero {
    id: number;
    nombreyape: string;
    tipo: string;
    fechaCarga: Date;
}